import { Router } from 'express';
import { authenticate, requireRole } from '../middleware/auth.js';
import { createLimiter, loginLimiter, trackLimiter } from '../middleware/rateLimit.js';
import { uploadProof, uploadRequestPhotos } from '../middleware/upload.js';
import { login } from '../controllers/auth.controller.js';
import { createErrand, trackErrand } from '../controllers/errands.controller.js';
import {
  assignAgent, closeErrand, completeErrand, getErrand, listAgents, listErrands, listPaymentIssues, markPaid, resolvePayment, setQuote,
} from '../controllers/admin.controller.js';
import { listMyErrands, updateStatus } from '../controllers/agent.controller.js';

const router = Router();

// Public
router.post('/errands', createLimiter, uploadRequestPhotos, createErrand);
router.get('/errands/track/:errand_id', trackLimiter, trackErrand);
router.post('/auth/login', loginLimiter, login);

// Admin
const admin = Router();
admin.use(authenticate, requireRole('admin'));
admin.get('/errands', listErrands);
admin.get('/errands/:id', getErrand);
admin.get('/agents', listAgents);
admin.get('/payments/issues', listPaymentIssues);
admin.put('/payments/:id/resolve', resolvePayment);
admin.put('/errands/:id/quote', setQuote);
admin.put('/errands/:id/assign', assignAgent);
admin.put('/errands/:id/payment', markPaid);
admin.put('/errands/:id/complete', completeErrand);
admin.put('/errands/:id/close', closeErrand);
router.use('/admin', admin);

// Agent
const agent = Router();
agent.use(authenticate, requireRole('agent'));
agent.get('/errands', listMyErrands);
agent.put('/errands/:id/status', uploadProof, updateStatus);
router.use('/agent', agent);

export default router;
