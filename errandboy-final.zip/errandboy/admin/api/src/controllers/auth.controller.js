import { createClient } from '@supabase/supabase-js';
import { z } from 'zod';
import { supabase } from '../config/supabase.js';
import { ApiError, asyncHandler, dbFail } from '../utils/errors.js';

const loginSchema = z.object({
  email: z.string().trim().email().max(200),
  password: z.string().min(1).max(200),
}).strict();

// POST /api/auth/login   body: { email, password }
// Signs in with Supabase Auth and returns a short-lived access token plus the user's role.
export const login = asyncHandler(async (req, res) => {
  const { email, password } = loginSchema.parse(req.body);
  if (!process.env.SUPABASE_ANON_KEY) throw new ApiError(500, 'Server is missing SUPABASE_ANON_KEY');

  // A throwaway client per sign-in. Never sign in with the shared service-role client:
  // it would start using that person's token for every later database call.
  const anon = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_ANON_KEY, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data, error } = await anon.auth.signInWithPassword({ email, password });
  if (error || !data?.session) throw new ApiError(401, 'Incorrect email or password');

  const { data: profile, error: dbError } = await supabase
    .from('users').select('name, role').eq('id', data.user.id).maybeSingle();
  if (dbError) dbFail(dbError);
  if (!profile) throw new ApiError(403, 'No profile for this account');

  res.json({ access_token: data.session.access_token, expires_in: data.session.expires_in, user: profile });
});
