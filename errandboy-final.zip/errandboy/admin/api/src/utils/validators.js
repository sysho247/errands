import { z } from 'zod';
import { SERVICE_TYPES, ERRAND_ID_RE } from './constants.js';
import { ApiError } from './errors.js';

// Multipart forms send objects as JSON text, so parse them first.
const parseJson = (v) => { if (typeof v !== 'string') return v; try { return JSON.parse(v); } catch { return v; } };
const note = (n) => z.string().trim().max(n).optional();

export const createErrandSchema = z.object({
  service_type: z.enum(SERVICE_TYPES),
  task_description: z.string().trim().min(5).max(3000), // for groceries this is the shopping list
  pickup_location: z.string().trim().max(300).optional(),
  delivery_location: z.string().trim().max(400).optional(),
  // ISO 8601, e.g. 2026-10-12T14:30:00+01:00. Empty string / null means "no preferred time".
  date_time: z.preprocess((v) => (v === '' || v === null ? undefined : v), z.coerce.date().optional()),
  contact_info: z.preprocess(parseJson, z.object({
    name: z.string().trim().min(2).max(100),
    phone: z.string().trim().regex(/^\+?[0-9\s-]{7,20}$/, 'Enter a valid phone number'),
    email: z.string().trim().email().max(200).optional(),
  }).strict()),
  // Extra answers from the service forms (grocery, moving, pharmacy, house hunting, ...): short text values with
  // snake_case names, e.g. { shopping_list: "...", pickup_floor: "3rd floor" }.
  details: z.preprocess(parseJson, z.record(z.string().regex(/^[a-z][a-z0-9_]{0,39}$/), z.string().trim().max(3000))
    .refine((o) => Object.keys(o).length <= 30, 'Too many detail fields')).optional(),
}).strict();

export const quoteSchema = z.object({
  quote_amount: z.coerce.number().positive().max(100_000_000).transform((n) => Math.round(n * 100) / 100),
  currency: z.enum(['NGN', 'USD']).default('NGN'),
  notify: z.array(z.enum(['email', 'whatsapp'])).max(2).default([]), // who gets the payment link
}).strict();

export const closeSchema = z.object({ note: z.string().trim().max(500).optional() }).strict();

export const assignSchema = z.object({ agent_id: z.string().uuid() }).strict();

export const paymentSchema = z.object({
  payment_reference: z.string().trim().min(4).max(100),
}).strict();

export const agentStatusSchema = z.object({
  status: z.enum(['On the way', 'In Progress', 'Proof Uploaded']),
  proof_notes: z.string().trim().max(2000).optional(),
});

// Accepts "eb-abc234" and normalises it; anything else is treated as not found.
export function parseErrandId(raw) {
  const id = String(raw || '').trim().toUpperCase();
  if (!ERRAND_ID_RE.test(id)) throw new ApiError(404, 'Errand not found');
  return id;
}
