-- Errand Boys: launch-phase schema (Supabase PostgreSQL)
-- Run in the Supabase SQL editor, or: psql "$DATABASE_URL" -f sql/001_schema.sql

create extension if not exists pgcrypto;

create type public.user_role as enum ('customer', 'agent', 'admin');
create type public.errand_status as enum
  ('Pending Review', 'Quoted', 'Paid', 'Assigned', 'On the way', 'In Progress', 'Proof Uploaded', 'Completed', 'Closed');

-- ---------------------------------------------------------------- users
-- id matches the Supabase Auth user, so a login token maps straight to a role.
create table public.users (
  id          uuid primary key references auth.users(id) on delete cascade,
  name        text not null check (length(trim(name)) between 2 and 100),
  email       text not null,
  phone       text,
  role        public.user_role not null default 'customer',
  is_active   boolean not null default true,   -- inactive agents are hidden from the assign dropdown
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create unique index users_email_lower_key on public.users (lower(email));
create index users_role_idx on public.users (role);

-- ----------------------------------------------------- errand id generator
-- EB-XXXXXX: 6 random characters from a 31-character alphabet (no 0/O/1/I/L).
-- ~887 million combinations. The loop plus the primary key guarantee uniqueness;
-- the API also retries on the rare concurrent clash (error code 23505).
create or replace function public.generate_errand_id() returns text
language plpgsql as $$
declare
  alphabet constant text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  candidate text;
  i int;
begin
  loop
    candidate := 'EB-';
    for i in 1..6 loop
      candidate := candidate ||
        substr(alphabet, 1 + (get_byte(gen_random_bytes(1), 0) % length(alphabet)), 1);
    end loop;
    exit when not exists (select 1 from public.errand_requests where errand_id = candidate);
  end loop;
  return candidate;
end $$;

create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- ------------------------------------------------------ errand_requests
create table public.errand_requests (
  errand_id          text primary key default public.generate_errand_id(),
  service_type       text not null,
  task_description   text not null check (length(trim(task_description)) >= 5),
  pickup_location    text,
  delivery_location  text,
  date_time          timestamptz,                       -- when the customer wants it done
  contact_info       jsonb not null,                    -- {"name": "...", "phone": "...", "email": "..."}
  status             public.errand_status not null default 'Pending Review',
  quote_amount       numeric(12,2) check (quote_amount is null or quote_amount > 0),
  quote_currency     text not null default 'NGN' check (quote_currency in ('NGN', 'USD')),
  payment_link       text,                              -- Paystack checkout link sent to the customer
  assigned_agent_id  uuid references public.users(id) on delete restrict,
  proof_notes        text,
  proof_urls         text[] not null default '{}',      -- private Storage paths in the "proofs" bucket
  details            jsonb not null default '{}'::jsonb, -- extra form answers, e.g. grocery: shopping_list, brands, budget, supermarket, landmark, instructions
  request_files      text[] not null default '{}',      -- customer photos (e.g. shopping list), private "requests" bucket
  payment_reference  text unique,                       -- Paystack reference (manual for now)
  paid_at            timestamptz,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),

  constraint errand_id_format check (errand_id ~ '^EB-[A-HJKMNP-Z2-9]{6}$'),
  constraint contact_info_shape check (contact_info ? 'name' and contact_info ? 'phone'),
  -- ::text keeps these checks safe to add right after ALTER TYPE ... ADD VALUE (see 002_upgrade.sql)
  constraint paid_needs_quote check
    (quote_amount is not null or status::text in ('Pending Review', 'Quoted', 'Closed')),
  constraint work_needs_agent check
    (assigned_agent_id is not null or status::text not in ('Assigned', 'On the way', 'In Progress', 'Proof Uploaded', 'Completed'))
);
create index errand_requests_status_idx on public.errand_requests (status);
create index errand_requests_agent_idx  on public.errand_requests (assigned_agent_id);
create index errand_requests_created_idx on public.errand_requests (created_at desc);

create trigger errand_requests_updated before update on public.errand_requests
  for each row execute function public.set_updated_at();
create trigger users_updated before update on public.users
  for each row execute function public.set_updated_at();

-- ------------------------------------------------- errand_status_history
-- Audit trail (who changed what, when). Optional but cheap, and useful for support and disputes.
create table public.errand_status_history (
  id           bigint generated always as identity primary key,
  errand_id    text not null references public.errand_requests(errand_id) on delete cascade,
  from_status  public.errand_status,
  to_status    public.errand_status not null,
  actor_id     uuid references public.users(id) on delete set null,
  note         text,
  created_at   timestamptz not null default now()
);
create index errand_status_history_errand_idx on public.errand_status_history (errand_id, created_at);

-- ------------------------------------------------------------ payments

create table if not exists public.payments (
  id               bigint generated always as identity primary key,
  errand_id        text not null references public.errand_requests(errand_id) on delete cascade,
  provider         text not null check (provider in ('paystack', 'flutterwave', 'mock')),
  reference        text not null unique,                 -- our reference, sent to the gateway
  amount           numeric(12,2) not null check (amount > 0),
  currency         text not null check (currency in ('NGN', 'USD')),
  checkout_url     text,
  -- pending : link created, not paid yet
  -- paid    : confirmed and applied to the errand
  -- stale   : money arrived but the quote changed / the errand moved on (needs a human)
  -- mismatch: amount or currency differed from what we asked for (needs a human)
  -- resolved: a human reviewed a stale/mismatch payment
  status           text not null default 'pending' check (status in ('pending', 'paid', 'stale', 'mismatch', 'resolved')),
  provider_txn_id  text,
  paid_at          timestamptz,
  created_at       timestamptz not null default now()
);
create index if not exists payments_errand_idx on public.payments (errand_id);
create index if not exists payments_status_idx on public.payments (status);
alter table public.payments enable row level security;   -- no policies: only the API (service role) can touch it

-- Applies a confirmed payment in ONE transaction, so a webhook that arrives twice
-- (gateways retry) or two at once can never pay an errand twice.
-- Returns: 'paid' | 'already_processed' | 'unknown_reference' | 'mismatch' | 'stale'
create or replace function public.confirm_payment(
  p_provider text, p_reference text, p_amount_minor bigint, p_currency text, p_txn_id text
) returns text
language plpgsql security definer set search_path = public as $$
declare
  pay public.payments;
  err public.errand_requests;
begin
  select * into pay from public.payments
   where reference = p_reference and provider = p_provider for update;
  if not found then return 'unknown_reference'; end if;
  if pay.status <> 'pending' then return 'already_processed'; end if;

  if round(pay.amount * 100)::bigint <> p_amount_minor or pay.currency <> p_currency then
    update public.payments set status = 'mismatch', provider_txn_id = p_txn_id, paid_at = now() where id = pay.id;
    return 'mismatch';
  end if;

  select * into err from public.errand_requests where errand_id = pay.errand_id for update;
  if err.status::text <> 'Quoted' or err.payment_reference is distinct from pay.reference then
    update public.payments set status = 'stale', provider_txn_id = p_txn_id, paid_at = now() where id = pay.id;
    return 'stale';
  end if;

  update public.payments set status = 'paid', provider_txn_id = p_txn_id, paid_at = now() where id = pay.id;
  update public.errand_requests set status = 'Paid', paid_at = now() where errand_id = err.errand_id;
  insert into public.errand_status_history (errand_id, from_status, to_status, note)
    values (err.errand_id, 'Quoted', 'Paid', 'Paid via ' || p_provider || ' (' || p_reference || ')');
  return 'paid';
end $$;

-- PostgREST exposes public functions as /rpc/... Only the server may call this one.
revoke all on function public.confirm_payment(text, text, bigint, text, text) from public, anon, authenticated;
grant execute on function public.confirm_payment(text, text, bigint, text, text) to service_role;

-- ----------------------------------------------------------- security
-- All access goes through the Express API using the service-role key.
-- RLS on with no policies = the public anon/authenticated keys can read nothing.
alter table public.users                 enable row level security;
alter table public.errand_requests       enable row level security;
alter table public.errand_status_history enable row level security;

-- Private bucket for agent proof uploads.
insert into storage.buckets (id, name, public) values ('proofs', 'proofs', false), ('requests', 'requests', false)
on conflict (id) do nothing;
