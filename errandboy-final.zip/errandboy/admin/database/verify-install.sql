-- Run after supabase-setup.sql to confirm everything was created. Each query says what to expect.

-- 1) Tables: expect 4 rows (errand_requests, errand_status_history, payments, users)
select table_name from information_schema.tables
where table_schema = 'public' and table_name in ('users', 'errand_requests', 'errand_status_history', 'payments')
order by table_name;

-- 2) Status lists: expect errand_status with 9 values in this order and user_role with customer, agent, admin
select t.typname as type, string_agg(e.enumlabel, ', ' order by e.enumsortorder) as values
from pg_type t join pg_enum e on e.enumtypid = t.oid
where t.typname in ('user_role', 'errand_status') group by t.typname;

-- 3) Functions: expect 3 rows (confirm_payment, generate_errand_id, set_updated_at)
select p.proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname in ('generate_errand_id', 'confirm_payment', 'set_updated_at')
order by p.proname;

-- 4) Security: expect 4 rows, all with row_level_security = true
select relname as table_name, relrowsecurity as row_level_security from pg_class
where relnamespace = 'public'::regnamespace
  and relname in ('users', 'errand_requests', 'errand_status_history', 'payments') order by relname;

-- 5) Photo folders: expect 2 rows (proofs, requests), both with public = false
select id, public from storage.buckets where id in ('proofs', 'requests') order by id;

-- 6) The ID generator: expect something like EB-K7M2QX (it does not save anything)
select public.generate_errand_id() as sample_errand_id;
