'use client';
import { useAuth } from '../lib/useAuth';
import LoginForm from './LoginForm';
import Dashboard from './Dashboard';

export default function AdminApp() {
  const { session, ready, login, logout, request } = useAuth('admin');
  if (!ready) return null;
  return session
    ? <Dashboard request={request} user={session.user} onLogout={logout} />
    : <LoginForm onLogin={login} />;
}
