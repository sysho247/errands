# errandboy/admin: everything behind the scenes

| Folder | What it is |
|---|---|
| `database/supabase-setup.sql` | Run once in Supabase. Creates every table, rule and storage folder |
| `api/` | The Errand Boys server (Node.js + Express): requests, quotes, payments, webhooks, notifications, agent jobs |
| `dashboard/` | The Next.js app: **admin dashboard** at `/` and **agent dashboard** at `/agent` |
| `deploy/` | Server files: nginx settings for the API and dashboard, and the pm2 file that keeps them running |

Setup, in order, is in **`../README.md`**. Each of `api/` and `dashboard/` also has its own README with details.
