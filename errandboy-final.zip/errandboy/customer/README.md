# customer/: the public website

Plain static files. No Node.js, no build step, no database on the server: any web server can host it.

| Path | What it is |
|---|---|
| `index.html` | The page shell |
| `assets/js/app.js` | All pages and features: Home, Services, request forms, Verify, Live agent, Track, Checkout, Thank you, About, Contact, legal pages, footer |
| `assets/css/styles.css` | All styling, including dark mode and mobile layout |
| `assets/img/` | Logo, favicon, home banner and the eight service photos |
| `config.js` | **The only file you edit**: API address, WhatsApp number, phone, email, bank details |
| `nginx-customer.conf` | Web-server settings for the VPS |

With `API_URL` empty the site works on its own (requests go to WhatsApp, tracking is a manual list).
With `API_URL` set to your API, requests and photos also reach the admin dashboard and Track shows live status.
After changing `assets/js/app.js` or `assets/css/styles.css`, raise the `?v=1` number in `index.html` so visitors get the new file.

To preview on your own computer: run `python3 -m http.server 8080` in this folder and open http://localhost:8080.
Full setup: `../README.md`.
